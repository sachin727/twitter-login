<?php 

	if(! function_exists('manager_id'))
	{
		function manager_id()
		{
			$CI = & get_instance();
			$CI->db->select('*');
			$CI->db->from('employees');
			$res = $CI->db->get();
			return $res->result();
		
		}
	}
	
	if(! function_exists('employee_id'))
	{
		function employee_id()
		{
			$CI = & get_instance();
			$CI->db->select('EMPLOYEE_ID');
			$CI->db->from('employees');
			$CI->db->order_by("EMPLOYEE_ID","desc");
			$res = $CI->db->get();
			return $res->row();
		
		}
	}
	
	if(! function_exists('edit_employee'))
	{
		function edit_employee($id)
		{
			$CI = & get_instance();
			$CI->db->select('*');
			$CI->db->from('employees');
			$CI->db->where('EMPLOYEE_ID',$id);
			$CI->db->order_by("EMPLOYEE_ID","desc");
			$res = $CI->db->get();
			return $res->row();
		
		}
	}
	
?>