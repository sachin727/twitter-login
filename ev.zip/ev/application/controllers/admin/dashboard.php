<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct()
       {
            parent::__construct();
            // Your own constructor code
			//prevent session cache on back button after logout
			clear_cache();
			$this->data = array();
       } 
	 
	 
	public function index()
	{		
			if(admin_logged_in() === FALSE) redirect('admin/login');
			$this->data['body'] = "admin/dashboard";
			$this->load->view('admin/structure', $this->data);
    }
	
}