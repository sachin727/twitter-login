<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Events extends CI_Controller {

	public function __construct()
       {
            parent::__construct();
            // Your own constructor code
			//prevent session cache on back button after logout
			clear_cache();
			$this->data = array();
       } 
	 
	 
	public function index()
	{		
			if(admin_logged_in() === FALSE) redirect('admin/login');
			$this->data['body'] = "admin/events";
			$this->load->view('admin/structure', $this->data);
    }
	
	
	public function add()
	{		
			if(admin_logged_in() === FALSE) redirect('admin/login');
			
			$this->form_validation->set_rules('event_title','Event Title','trim|required');
			//$this->form_validation->set_rules('event_image','Event Image','trim|required');
			$this->form_validation->set_rules('event_start_date','Event Start Date','trim|required');
			$this->form_validation->set_rules('event_end_date','Event End Date','trim|required');
			$this->form_validation->set_rules('event_start_time','Event Start Time','trim|required');
			$this->form_validation->set_rules('event_end_time','Event End Time','trim|required');
			$this->form_validation->set_rules('event_description','Event Description','trim|required');
			$this->form_validation->set_rules('event_venue','Event Venue','trim|required');
			$this->form_validation->set_rules('event_venue_latitude','Enter correct location and click on Check on Map Button','trim|required');
			$this->form_validation->set_rules('event_venue_longitude','Enter correct location and click on Check on Map Button','trim|required');
			
			$this->form_validation->set_error_delimiters('<div class="error">','</div>');
			if($this->form_validation->run()==TRUE)
			{
				$event_data = array(
									'event_title' => EscapeData($this->input->post('event_title')),
									//'event_image' => $this->input->post('event_image'),
									'event_start_date' => EscapeData($this->input->post('event_start_date')),
									'event_end_date' => EscapeData($this->input->post('event_end_date')),
									'event_start_time' => EscapeData($this->input->post('event_start_time')),
									'event_end_time' => EscapeData($this->input->post('event_end_time')),
									'event_description' => EscapeData($this->input->post('event_description')),
									'event_venue' => EscapeData($this->input->post('event_venue')),
									'event_venue_latitude' => EscapeData($this->input->post('event_venue_latitude')),
									'event_venue_longitude' => EscapeData($this->input->post('event_venue_longitude')),
									'event_category_id' => implode(',',$this->input->post('event_category')),
									'create_time' => date('Y-m-d H:i:s')
							);
				/* echo "<pre>";
				print_r($event_data);
				echo "</pre>";
				exit;	 */
				
				$sub_event_data = array();

				
				
			}
			
			$this->data['body'] = "admin/events/add";
			$this->load->view('admin/structure', $this->data);
    }
	
	public function check_lat_long()
	{
		if(admin_logged_in() === FALSE) redirect('admin/login');
		$data = $_REQUEST['address'];
		// $address = urldecode($data['address']);
		$address = urldecode($data);
		$symbol = array(" ", ",", "_");
		$keyword = str_replace($symbol, "+", $address);

		$geocode 	= $this->file_get_contents_curls('http://maps.google.com/maps/api/geocode/json?address=' . $keyword . '&sensor=false');
		$output 	= json_decode($geocode);
		if(isset($output->results[0]->geometry->location->lat) or isset($output->results[0]->geometry->location->lng))
		{
			$latitude = $post['latitude'] = $output->results[0]->geometry->location->lat;
			$longitude = $post['longitude'] = $output->results[0]->geometry->location->lng;
			$msg = $latitude.'::'.$longitude;
		}
		
		if(($output->status == 'ZERO_RESULTS') or (($latitude=='' || $longitude=='')))
		{
			$msg = 'Unable to find latitude and longitude. Please enter proper address.';
		}
		
		echo $msg;
		//return $msg;
	}
	
	public function file_get_contents_curls($url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
		$data = curl_exec($ch);
		curl_close($ch);
		return $data;
	}
		
}