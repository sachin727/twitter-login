<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//prevent session cache on back button after logout
		clear_cache();
		$this->data = array();
	} 
	 
	public function index()
	{		
			if(admin_logged_in() === TRUE) redirect('admin/dashboard');
			if(isset($_POST['login']))
			{
               if(count($this->check_admin_login()))
               {
					if($this->check_admin_login()->status==1)
					{
						$session_data = array(
							'admin_id'   =>$this->check_admin_login()->id,
							'username'   =>$this->check_admin_login()->username
							);
							
						$this->session->set_userdata($session_data);
						redirect('admin/dashboard');
					}
					else
					{
					 $this->session->set_flashdata("msg_error", "Your account inactive.");
					 redirect("admin/login");  
					}
                }
                else
                {                    
                    $this->session->set_flashdata("msg_error", "Invalid username or password");
                     redirect("admin/login");  
                }            
            }
		$this->data['body'] = "admin/login";
		$this->load->view('admin/structure_login', $this->data);
       
    }
	
	function check_admin_login()
    {	 
        $username = $this->input->post('username');
        $password = md5($this->input->post('password_login'));
        $select = array("id", "username", "status");
        $from = array('admin_login');
        $where = array("username"=>$username, "password_login"=>$password);
		return $this->common_model->get_record($select, $from, $where);
    }
	 
}