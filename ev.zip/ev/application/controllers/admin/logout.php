<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Logout extends CI_Controller {

	public function __construct()
       {
            parent::__construct();
			//prevent session cache on back button after logout
			clear_cache();
			$this->data = array();
       } 
	 
	 
	public function index()
	{				
		$session_data = array(
						'admin_id'   =>'',
						'username'   =>''
						);
		$this->session->unset_userdata($session_data);
		$this->session->sess_destroy();
		redirect('admin/login');
			
    }
	 
}