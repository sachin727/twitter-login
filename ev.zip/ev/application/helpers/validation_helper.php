<?php
defined('BASEPATH') OR exit('No direct script access allowed');
    function get_mysql()
    { 
    $db = (array)get_instance()->db;
    $con= mysql_connect($db['hostname'], $db['username'], $db['password']);
    return mysql_select_db($db['database'],$con);
    }

    function EscapeData($Data)
    {
        $Data = strip_tags($Data);
        return mysql_real_escape_string(trim(stripcslashes($Data)));
    }
    
    function EscapeDataWithoutStrip($Data)
    {
        return mysql_real_escape_string(trim(stripcslashes($Data)));
    }
    
    
?>