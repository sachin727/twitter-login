<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_model extends CI_Model {
        
        public function __construct()
            {        
                parent::__construct();
            }
         
		public function insert($table_name = '', $data = '')
		{
			$query = $this->db->insert($table_name, $data);
			if ($query) return $this->db->insert_id();
			else return FALSE;
		}
		 
        function get_records_count($select,$from,$where)
        {
            $this->db->select($select);
            $this->db->from($from);
            $this->db->where($where);
            $query=$this->db->get();
            return $query->num_rows();
        }
        
        function get_records_count_all($select,$from)
        {
            $this->db->select($select);
            $this->db->from($from);
            $query=$this->db->get();
            return $query->num_rows();
        }
		
		function get_records($from,$where)
        {
            $this->db->from($from);
            $this->db->where($where);
			$query=$this->db->get();
			return $query->result();
        }
		
		function get_records_wherein($from,$column,$where)
        {
            $this->db->from($from);
            $this->db->where_in($column,$where);
			$query=$this->db->get();
            return $query->result();
        }
		
		function get_distinct_records_count($select,$from,$where)
        {
			$this->db->distinct();
			$this->db->select($select);
			$this->db->from($from);
			$this->db->where($where); 
			$query=$this->db->get();
            return $query->num_rows();
		}
		
		function get_all($from)
        { 
            $this->db->from($from);
            $query=$this->db->get();
            return $query->result();
        }
        
        function get_record($select,$from,$where)
        {
            $this->db->select($select);
            $this->db->from($from);
            $this->db->where($where);
            $query=$this->db->get();
            return $query->row();
        }
		
		function get_record_orderby($select,$from,$where,$order_by,$order_by_val)
        {
            $this->db->select($select);
            $this->db->from($from);
            $this->db->where($where);
			$this->db->order_by($order_by,$order_by_val);
            $query=$this->db->get();
            return $query->row();
        }
		
		function get_records_where($select,$from,$where)
        {
			$this->db->select($select);
            $this->db->from($from);
            $this->db->where($where);
			$query=$this->db->get();
			return $query->result();
        }
		
		function get_records_with_or_where($select,$from,$where,$or_where,$order_by,$order_by_val)
        {
			$this->db->select($select);
            $this->db->from($from);
			$this->db->where($where);
			$this->db->or_where($or_where);
			$this->db->order_by($order_by,$order_by_val);
			$query=$this->db->get();
			return $query->result();
        }
		
		function get_join_row_two_table($onetable,$twotable,$idone,$idtwo,$where)
        {
            $this->db->select('*');
            $this->db->from($onetable);
            $this->db->join($twotable, $twotable.'.'.$idone.'='.$onetable.'.'.$idtwo);
            $this->db->where($where);
            $query = $this->db->get();
            return $query->row();
        }
		
		function get_join_row_two_table_orderby($onetable,$twotable,$idone,$idtwo,$where,$order_by,$order_by_val)
        {
            $this->db->select('*');
            $this->db->from($onetable);
            $this->db->join($twotable, $twotable.'.'.$idone.'='.$onetable.'.'.$idtwo);
            $this->db->where($where);
			$this->db->order_by($order_by,$order_by_val);
            $query = $this->db->get();
            return $query->row();
        }
		
		function get_join_result_two_table_orderby_limit($onetable,$twotable,$idone,$idtwo,$where,$order_by,$order_by_val)
        {
            $this->db->select('*');
            $this->db->from($onetable);
            $this->db->join($twotable, $twotable.'.'.$idone.'='.$onetable.'.'.$idtwo);
            $this->db->where($where);
			$this->db->order_by($order_by,$order_by_val);
			$this->db->limit(2);
            $query = $this->db->get();
            return $query->row();
        }
		
		function get_join_result_two_table_orderby($onetable,$twotable,$idone,$idtwo,$where,$order_by,$order_by_val)
		{
            $this->db->select('*');
            $this->db->from($onetable);
            $this->db->join($twotable, $twotable.'.'.$idone.'='.$onetable.'.'.$idtwo);
			$this->db->order_by($order_by,$order_by_val);
            $this->db->where($where);
            $query = $this->db->get();
            return $query->result();
        }
		
		function get_join_result_three_table($onetable,$twotable,$threetable,$idone,$idtwo,$idthree,$idfour,$where,$order_by,$order_by_val)
        {
            $this->db->select('*');
			$this->db->from($onetable); 
            $this->db->join($twotable, $twotable.'.'.$idone.'='.$onetable.'.'.$idtwo);
			$this->db->join($threetable, $threetable.'.'.$idthree.'='.$twotable.'.'.$idfour);
			$this->db->where($where);
			$this->db->order_by($order_by,$order_by_val);
			$this->db->group_by($twotable.".id");
			$this->db->having('COUNT(*)>=',1);
            $query = $this->db->get();
            return $query->result();
        }
		
		function get_join_result_two_table($onetable,$twotable,$idone,$idtwo,$where)
        {
            $this->db->select('*');
            $this->db->from($onetable);
            $this->db->join($twotable, $twotable.'.'.$idone.'='.$onetable.'.'.$idtwo);
            $this->db->where($where);
            $query = $this->db->get();
            return $query->result();
        }
		
		function update_allrecords($table,$field,$where) //updating data into DB
        {
            $this->db->set($field);
            $this->db->where($where);
            $this->db->update($table);
        }
		
		function get_max_record($col,$table,$where)
		{
			$this->db->select_max($col);
            $this->db->from($table);
            $this->db->where($where);
            $query = $this->db->get();
            return $query->row();
		}
		
		function get_records_count_group_by($select,$from,$where,$group_by)
        {
			$this->db->select($select);
			$this->db->from($from);
            $this->db->where($where);
			$this->db->group_by($group_by);
			$query=$this->db->get();
			return $query->result();
        }
		
		public function delete($table_name = '', $id = '')
		{
			return $this->db->delete($table_name, $id);
		}
		
}
?>