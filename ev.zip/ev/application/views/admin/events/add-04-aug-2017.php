<div id="page-wrapper" >
	<div class="header">   
		<ol class="breadcrumb">
		  <li><a href="<?php echo base_url('admin/dashboard');?>">Home</a></li>
		  <li><a href="<?php echo base_url('admin/events');?>">Events</a></li>
		  <li class="active">Add Event</li>
		</ol> 						
	</div>
		
	<div id="page-inner"> 
	  <div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					Add Event
				</div>
				<div class="panel-body">
				
				<form enctype="multipart/form-data" method="post" class="form-vertical" onsubmit="return validate_add_event();">
					<div class="row">
					<div class="col-sm-6">
					<div class="row">
					<div class="col-sm-4"><div class="form-group">Event Title<span class="required_text">*</span></div></div>
					<div class="col-sm-8"><div class="form-group"><input type="text" name="event_title" id="video_name" class="form-control required_add_event noeventspecharallowed" maxlength="100"/></div></div></div>
					</div>
					<div class="col-sm-6">
					<div class="row">
					<div class="col-sm-4"><div class="form-group">Event Image<span class="required_text">*</span></div></div>
					<div class="col-sm-8"><div class="form-group"><input type="file" name="event_image" id="event_image" onchange="UploadEventImage(this);"/><div id="event_image_error" class="required_text"></div></div></div>
					</div></div>
					</div>
				<div class="row">
					<div class="col-sm-6">
					<div class="row">
					<div class="col-sm-4"><div class="form-group">Event Start Date<span class="required_text">*</span></div></div>
					<div class="col-sm-8">
						<div class="form-group">
							<input type='text' class="form-control datepicker-small required_add_event" name="start_date" placeholder="Click on icon to select date" id="datepicker_from" readonly/>
						</div>
					</div>
					</div>
					</div>
					<div class="col-sm-6">
					<div class="row">
					<div class="col-sm-4"><div class="form-group">Event End Date<span class="required_text">*</span></div></div>
					<div class="col-sm-8"><div class="form-group">
							<input type='text' class="form-control datepicker-small required_add_event" name="end_date" placeholder="Click on icon to select date" id="datepicker_to" readonly/>
						</div>
					</div>
					</div>
					</div>
					
				</div>
				
				<div class="row">
					<div class="col-sm-6">
					<div class="row">
					<div class="col-sm-4"><div class="form-group">Event Start Time<span class="required_text">*</span></div></div>
					<div class="col-sm-8"><div class="form-group">
						<div class="input-append">
							<input id="event_start_time" type="text" class="form-control required_add_event" readonly/>
							<span class="add-on"><i class="icon-time"></i></span>
						</div></div>
					</div>
					</div>
					</div>
					<div class="col-sm-6">
					<div class="row">
					<div class="col-sm-4"><div class="form-group">Event End Time<span class="required_text">*</span></div></div>
					<div class="col-sm-8"><div class="form-group">
						<div class="input-append">
							<input id="event_end_time" type="text" class="form-control required_add_event" readonly/>
							<span class="add-on"><i class="icon-time"></i></span>
						</div></div>
					</div>
					</div>
					</div>
					
				</div>
				
				<div class="row">
					<div class="col-sm-6">
					<div class="row">
					<div class="col-sm-4"><div class="form-group">Event Description<span class="required_text">*</span></div></div>
					<div class="col-sm-8"><div class="form-group"><textarea name="event_description" class="form-control required_add_event"></textarea></div></div>
					
					<div class="col-sm-4"><div class="form-group">Event Venue<span class="required_text">*</span></div></div>
					<div class="col-sm-8">
						<div class="form-group">
							<textarea name="event_venue" id="address_sys" class="form-control required_add_event"></textarea>
							<br>
							<button onclick="CheckLatLong(this,'<?php echo base_url();?>');" type="button" class="btn btn-default">Check On Map</button>
							<span id="chk_msg_id"></span><div id="event_venue_error" class="required_text"></div> 
						</div>
					</div>
					</div>
					</div>
					<div class="col-sm-6">
					<!-- Map Start -->
					<div id="infoPanel">
						<div id="markerStatus" style="display:none;"><i>Click and drag the marker.</i></div>
						<div id="address" style="display:none;"></div>
					</div>
					
					<div id="mapCanvas"></div>
					<input type="hidden" value="" name="event_latitude" class="latlong_required" id="latitude" readonly />
					<input type="hidden" value="" name="event_logitude" class="latlong_required" id="longitude" readonly />
					<!-- Map End -->
					</div>
				</div>
				
				<div class="row panel-heading">
					<strong>Sub-Event Details</strong>
				</div>
				<div class="row">
					<div class="col-sm-6">
						<div class="row">
							<div class="col-sm-4"><div class="form-group">Sub-Events</div></div>
							<div class="col-sm-8">
								<div class="form-group">
									<?php
									$categories = get_event_categories();
									if($categories!=''){
									foreach($categories as $category){
									?>
									<input name="event_category[]" id="event_category_<?php echo $category->id;?>" type="checkbox" value="<?php if($category->id != '') echo $category->id;?>" onclick="CheckCategory(<?php echo $category->id;?>);"/> <?php if($category->category_name!='')echo ucfirst($category->category_name);' &nbsp;'?>
									<?php } }?>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="row">
							<div class="col-sm-4"><div class="form-group"></div></div>
							<div class="col-sm-8"><div class="form-group"></div></div>
						</div>
					</div>
				</div>
					
				<div class="row">
				<div class="col-sm-12">
					<div class="accordion" id="accordion2">
					<?php
					if($categories!=''){
					foreach($categories as $category){
					?>
						<div class="accordion-group">
							<div class="accordion-heading" id="div_accordian_<?php echo $category->id;?>">
								<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_<?php echo $category->id;?>">
								<?php if($category->category_name!='')echo ucfirst($category->category_name);?>
								</a>
							</div>
							
							<div id="collapse_<?php echo $category->id;?>" class="accordion-body collapse">
								<div class="accordion-inner">
									<input type="hidden" name="no_of_sub_events_hidden" id="no_of_sub_events_hidden_<?php echo $category->id;?>" value="1" />
									<input type="button" id="add_sub_events_btn_<?php echo $category->id;?>" onclick="return AddCategoryRow(this,<?php echo $category->id;?>,0);" value="Add More Sub-events" class="btn btn-primary" />
									<br/>
									
									<div id="no_of_sub_events_<?php echo $category->id;?>">1</div>
	
								<div class="sub_events_section" id="sub_events_section_<?php echo $category->id;?>">
								<div id="sub_event_row_0" class="sub_event_row"><input type="hidden" name="sub_event_row_hidden[]" id="sub_event_row_hidden_<?php echo $category->id;?>" value="0"/>
									<div class="row">
										<div class="col-sm-3">
											<div class="form-group">
												<input type="text" name="sub_event_title[]" class="form-control" placeholder="Sub-Event Title" title="Sub-Event Title"/>
											</div>
										</div>
										
										<div class="col-sm-3">
											<div class="form-group">
												<textarea class="form-control" name="sub_event_description[]" placeholder="Sub-Event Description" title="Sub-Event Description"></textarea>
											</div>
										</div>
										
										<div class="col-sm-3">
											<div class="form-group">
												<textarea class="form-control" name="sub_event_background[]" placeholder="Sub-Event Background" title="Sub-Event Background"></textarea>
											</div>
										</div>
										
										<?php if($category->id == 1){ //category:Cultural?>
										
										<div class="col-sm-3">&nbsp;</div>
										
										<div class="clearfix"></div>
										
										<div class="col-sm-3">
											<div class="form-group">
												<input type="text" name="sub_event_artist_name[]" class="form-control" placeholder="Sub-Event Artist Name" title="Sub-Event Artist Name"/>
											</div>
										</div>
										
										<div class="col-sm-3">
											<div class="form-group">
												<input type="text" name="sub_event_cordinators[]" class="form-control" placeholder="Sub-Event Cordinators" title="Sub-Event Cordinators. Enter comma separated names here."/>
											</div>
										</div>
										
										<div class="col-sm-3">
											<div class="form-group">
												<input type="text" name="sub_event_participants[]" class="form-control" placeholder="Sub-Event Participants" title="Sub-Event Participants. Enter comma separated names here."/>
											</div>
										</div>
										
										<?php }?>
										
										<?php if($category->id == 2){ //category:Food?>
										<div class="col-sm-2">
											<div class="form-group">
												Stall Layout <input type="file" name="stall_layout[]" title="Stall Layout" />
											</div>
										</div>
										
										<div class="col-sm-2">
											<div class="form-group">
												Menu Layout <input type="file" name="menu_layout[]" title="Menu Layout" />
											</div>
										</div>
										<?php }?>
										
										
										<?php if($category->id == 3){ //category:Store?>
										<div class="col-sm-2">
											<div class="form-group">
												Store images 
												<input type="file" name="store_images[]" title="Multiple Store images" />
											</div>
										</div>
										<?php }?>
										
										<?php /* ?><br/><div class="col-sm-1"><a href="#" id="sub_event_delete_0" class="btn btn-default" onclick="return DeleteCategoryRow('0','<?php echo $category->id;?>')">Delete</a></div><?php */?>
									</div><!-- row--></div></div>
									
								</div>
							</div>
						</div><!-- accordian-group -->
					<?php } }?>

					</div>
					</div>	
				</div><!-- row end -->
				
				
				<div class="col-sm-12">
					<button type="submit" class="btn btn-warning">Submit Button</button>
					<button type="reset" class="btn btn-default">Reset Button</button>
				</div>
				
				</form>
				
				</div>
				<!-- /.panel-body -->
			</div>
			<!-- /.panel -->
		</div>
		<!-- /.col-lg-12 -->
	</div>
			