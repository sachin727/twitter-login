<footer><p>All right reserved. <a href="#">Event Management | Admin</a></p>
				
        
				</footer>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
	
<?php 
$segment1 = $this->uri->segment(1);
$segment2 = $this->uri->segment(2);
$segment3 = $this->uri->segment(3);
?>
	
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/jquery.metisMenu.js"></script>
	
	<?php if($segment1 == 'admin' && $segment2 == 'events' && $segment3 == 'add'){?>
	<link rel="stylesheet" href="<?php echo base_url(ADMIN_THEME_URL); ?>/css/datepicker/jquery-ui.css">
	<link rel="stylesheet" href="<?php echo base_url(ADMIN_THEME_URL); ?>/css/datepicker/ui-style.css">
	<script src="<?php echo base_url(ADMIN_THEME_URL); ?>/js/datepicker/jquery-ui.js"></script>
	<script type="text/javascript">
	jQuery(function () {
		jQuery( "#datepicker_from" ).datepicker({
			showOn: "button",
			buttonImage: "<?php echo base_url(ADMIN_THEME_URL); ?>/img/calendar.gif",
			buttonImageOnly: true,
			buttonText: "Click To Select From Date. From Date will always be smaller then To Date",
			minDate: 'today',
			changeYear: true,
			changeMonth: true,
			onSelect: function(selected) {
			  jQuery("#datepicker_to").datepicker("option","minDate", selected)
			}
		});
		
		var date_from_val = jQuery( "#datepicker_from" ).val();
		
		jQuery( "#datepicker_to" ).datepicker({
			showOn: "button",
			buttonImage: "<?php echo base_url(ADMIN_THEME_URL); ?>/img/calendar.gif",
			buttonImageOnly: true,
			buttonText: "Click To Select To Date. To Date will always be grater then From Date",
			// maxDate: 'today',
			minDate: date_from_val,
			changeYear: true,
			changeMonth: true,
			onSelect: function(selected) {
			}
		});
	});
	</script>
	
	<link rel="stylesheet" href="<?php echo base_url(ADMIN_THEME_URL); ?>/css/datepicker/jquery.timepicker.css">
	<script src="<?php echo base_url(ADMIN_THEME_URL); ?>/js/datepicker/jquery.timepicker.js"></script>
	<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
	<script src="<?php echo base_url(ADMIN_THEME_URL);?>/scripts/custom_event_script.js"></script>
	<?php }?>
	
	<?php if($segment1 == 'admin' && $segment2 == 'dashboard'){?>
	<!-- Custom Js -->
    <script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/custom-scripts.js"></script>
    <!-- Morris Chart Js -->
    <script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/morris/raphael-2.1.0.min.js"></script>
    <script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/morris/morris.js"></script>
	<script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/easypiechart.js"></script>
	<script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/easypiechart-data.js"></script>
	<script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/Lightweight-Chart/jquery.chart.js"></script>
	<?php }?>
	
	<script src="<?php echo base_url(ADMIN_THEME_URL);?>/scripts/custom_validation.js"></script>
</body>
</html>