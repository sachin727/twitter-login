<!-- BEGIN BODY -->
<body class="login-body">
<div class="login-bg">
<div class="col-sm-4 col-sm-push-4">

  <div class="login-header">
      <!-- BEGIN LOGO -->
      <div id="logo" class="center">
          <img src="<?php echo base_url(ADMIN_THEME_URL);?>/img/logo.png" alt="logo" class="center" />
      </div>
      <!-- END LOGO -->
  </div>
<!-- BEGIN LOGIN -->
<div class="login-main">
  <div id="login">
    <!-- BEGIN LOGIN FORM -->
    <form id="loginform" class="form-vertical no-padding no-margin" method="post" onsubmit="return validate_admin_login()">      
     
          <h4>Admin Login</h4>
          <div class="col-sm-8 col-sm-push-2">
              <div class="form-group">
                  <div class="input-prepend">                      
					  <input type="text" name="username" class="required_login form-control" placeholder="Username" />
				  </div>
              </div>
          </div>
          <div class="col-sm-8 col-sm-push-2">
              <div class="form-group">
                  <div class="input-prepend">
                      <span class="add-on"><i class="icon-key"></i></span>
					  <input type="password" name="password_login" class="required_login form-control" placeholder="Password" minlength="6" />
                  </div>				  
				  <?php echo display_alert_admin();?>				  
                  <div class="mtop10">
                      <div class="block-hint pull-right">
                          <a href="javascript:;" class="" id="forget-password">Forgot Password?</a>
                      </div>
                  </div>
                  <div class="clearfix space5"></div>
              </div>
          </div>
      <div class="col-sm-8 col-sm-push-2">
              <div class="form-group">
      <input type="submit" id="login-btn" class="btn btn-block btn-warning" name="login" value="Login" />
	  </div><p>&nbsp;</p>
	</div>
    </form>
    <!-- END LOGIN FORM -->    
	</div>
	</div>
	</div>
	</div>
	