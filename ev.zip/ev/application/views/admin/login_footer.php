<!-- BEGIN COPYRIGHT -->
</div>
  
  <!-- END COPYRIGHT -->
  <!-- BEGIN JAVASCRIPTS -->
  <?php /*?><script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/jquery.min.js"></script><?php */?>
  <script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/jquery-1.10.2.js"></script>
   <script src="<?php echo base_url(ADMIN_THEME_URL);?>/scripts/custom_validation.js"></script>
  <script src="<?php echo base_url(ADMIN_THEME_URL);?>/assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url(ADMIN_THEME_URL);?>/js/scripts.js"></script>
 
  <script>
    jQuery(document).ready(function() {     
      App.initLogin();
    });
  </script>
  <!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>

