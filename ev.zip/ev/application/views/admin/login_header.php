<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Event Management </title>
	<link href="<?php echo base_url(ADMIN_THEME_URL);?>/css/event_style.css" rel="stylesheet">
<link href="<?php echo base_url(ADMIN_THEME_URL);?>/css/bootstrap.min.css" rel="stylesheet">
    
</head>