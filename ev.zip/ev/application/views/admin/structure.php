<?php $this->load->view('admin/header');?>
<?php $this->load->view($body);?>
<?php $this->load->view('admin/footer');?>