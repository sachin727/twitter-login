<?php $this->load->view('admin/login_header');?>
<?php $this->load->view($body);?>
<?php $this->load->view('admin/login_footer');?>