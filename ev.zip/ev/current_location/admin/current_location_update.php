<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) )
die( '-1' );

global $wpdb;

$query_location = "SELECT * FROM ". $wpdb->base_prefix ."current_location WHERE id = 1";
$result_location = $wpdb->get_row( $query_location );
?>

<style>
.ajax-loader
{
	background: url("<?php echo PLUGIN_CURRENT_LOCATION_URL;?>/assets/ajax-loader.gif") no-repeat scroll center center rgba(0, 0, 0, 0) !important;	
}
</style>

<div class="wrap">
    <h1>Current Location</h1>
<?php
if($msg)
{
?>
<div id="message" class="updated notice notice-success is-dismissible below-h2">
<p>
<?php echo $msg;?>
</p>
<button class="notice-dismiss" type="button">
<span class="screen-reader-text">Dismiss this notice.</span>
</button>
</div>
<?php }?>
    <form name="update_location" method="post" action="admin.php?page=current_location&p_action=<?php echo base64_encode('update_location')?>" id="update_location_form" class="form-horizontal" onsubmit="return validateLocation(this);" >
        <div id="poststuff">
            <div id="post-body" class="metabox-holder columns-2">
                <div id="post-body-content" style="position: relative;">
                    <table class="form-table">
                        <tbody>
                            <tr>
                                <td valign="top"><div class="col-lg-2">Name:</div></td>
                                <td valign="top"><div class="col-lg-4"><input type="text" size="30" name="name" class="required" value="<?php echo $result_location->name;?>" /></div></td>
								<td valign="top" rowspan="4"><div id="mapCanvas"></div>
									  <div id="infoPanel">
										<b>Marker status:</b>
										<div id="markerStatus"><i>Click and drag the marker.</i></div>
										<b>Closest matching address:</b>
										<div id="address"></div>
									  </div>
									<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
									<script type="text/javascript">
									function CheckLatLong(me, site_url)
									{
										jQuery(me).addClass('ajax-loader');
										jQuery(me).attr('disabled','disabled');
										jQuery('#chk_msg_id').html("Pease wait. Searching address...!");
										var address = encodeURIComponent(jQuery("#address_sys").val().trim());
										
										var data	= '&address='+address;
										var blogUrl = site_url;

										request_Url =  blogUrl+'/wp-admin/admin-ajax.php?action=CheckLatLong'+ data;
										jQuery.ajax({  
										type: 'POST',
										url:  request_Url,
										success: function(data, textStatus, XMLHttpRequest){  
										data = data.split( '::' );

										if(data[0] == 'Unable to find latitude and longitude. Please enter proper address.' )
										{
											alert(data[0]);
										}
										else
										{
											//alert("in else");
											jQuery('#latitude').val(data[0]);
											jQuery('#longitude').val(data[1]);
											//var latLng = new google.maps.LatLng(data[0], data[1]);
											//updateMarkerPosition(latLng);
											initialize2(data[0], data[1]);
										}
										},
										error: function(XMLHttpRequest, textStatus, errorThrown){  
										}
										});
										jQuery(me).removeClass('ajax-loader');
										jQuery(me).removeAttr('disabled');
										jQuery('#chk_msg_id').html("");
										return false;
									}
									
									function initialize2(lat2, long2)
									{
										var latLng = new google.maps.LatLng(lat2, long2);
										  var map = new google.maps.Map(document.getElementById('mapCanvas'), {
											zoom: 18,
											center: latLng,
											mapTypeId: google.maps.MapTypeId.ROADMAP
										  });
										  var marker = new google.maps.Marker({
											position: latLng,
											title: 'Point A',
											map: map,
											draggable: true
										  });

										  // Update current position info.
										  updateMarkerPosition(latLng);
										  geocodePosition(latLng);

										  // Add dragging event listeners.
										  google.maps.event.addListener(marker, 'dragstart', function() {
											updateMarkerAddress('Dragging...');
										  });

										  google.maps.event.addListener(marker, 'drag', function() {
											updateMarkerStatus('Dragging...');
											updateMarkerPosition(marker.getPosition());
										  });

										  google.maps.event.addListener(marker, 'dragend', function() {
											updateMarkerStatus('Drag ended');
											geocodePosition(marker.getPosition());
										  });
									}
									var geocoder = new google.maps.Geocoder();

									function geocodePosition(pos) {
									  geocoder.geocode({
										latLng: pos
									  }, function(responses) {
										if (responses && responses.length > 0) {
										  updateMarkerAddress(responses[0].formatted_address);
										} else {
										  updateMarkerAddress('Cannot determine address at this location.');
										}
									  });
									}

									function updateMarkerStatus(str) {
									  document.getElementById('markerStatus').innerHTML = str;
									}

									function updateMarkerPosition(latLng) {
										jQuery('#latitude').val(latLng.lat());
										jQuery('#longitude').val(latLng.lng());
									}

									function updateMarkerAddress(str) {
									  document.getElementById('address').innerHTML = str;
									}

									function initialize() {
									  var latLng = new google.maps.LatLng(<?php echo $result_location->latitude;?>, <?php echo $result_location->longitude;?>);
									  var map = new google.maps.Map(document.getElementById('mapCanvas'), {
										zoom: 18,
										center: latLng,
										mapTypeId: google.maps.MapTypeId.ROADMAP
									  });
									  var marker = new google.maps.Marker({
										position: latLng,
										title: 'Point A',
										map: map,
										draggable: true
									  });

									  // Update current position info.
									  updateMarkerPosition(latLng);
									  geocodePosition(latLng);

									  // Add dragging event listeners.
									  google.maps.event.addListener(marker, 'dragstart', function() {
										updateMarkerAddress('Dragging...');
									  });

									  google.maps.event.addListener(marker, 'drag', function() {
										updateMarkerStatus('Dragging...');
										updateMarkerPosition(marker.getPosition());
									  });

									  google.maps.event.addListener(marker, 'dragend', function() {
										updateMarkerStatus('Drag ended');
										geocodePosition(marker.getPosition());
									  });
									}

									// Onload handler to fire off the app.
									google.maps.event.addDomListener(window, 'load', initialize);
									</script>
									  <style>
									  #mapCanvas {
										width: 500px;
										height: 400px;
										float: left;
									  }
									  #infoPanel {
										float: left;
										margin-left: 10px;
									  }
									  #infoPanel div {
										margin-bottom: 5px;
									  }
									  </style></td>
                            </tr>
                            <tr>
                                <td valign="top"><div class="col-lg-2">Address:</div></td>
                                <td valign="top">
									<div class="col-lg-4">
										<textarea name="address" class="required" id="address_sys" rows="4" cols="40"><?php echo $result_location->address;?></textarea>
										<br/>
										<button onclick="CheckLatLong(this,'<?php echo get_site_url();?>');" type="button" class="button-primary">Check On Map</button>
										<span id="chk_msg_id"></span>
									</div>
								</td>
                            </tr>
                             <tr>
                                <td valign="top"><div class="col-lg-2">Latitude:</div></td>
                                <td valign="top"><div class="col-lg-4"><input type="text" value="" size="30" name="latitude" class="required" id="latitude" readonly /></div></td>
                            </tr>
                              <tr>
                                <td valign="top"><div class="col-lg-2">Longitude:</div></td>
                                <td valign="top"><div class="col-lg-4"><input type="text" value="" size="30" name="longitude" class="required" id="longitude" readonly />
                                <span id="numeric_validation"></span></div></td>
                            </tr>
                               <tr>
                                <td valign="top"></td>
                                <td valign="top"><div class="col-lg-4"><input type="submit" name="submit" value="Save" class="button-primary" />
                                <a href="<?php echo get_admin_url();?>index.php" class="button-primary"><?php echo ' Close '; ?></a>
                               </div></td>
                            </tr>							
                        </tbody>
                    </table>
                </div>                       
                <br class="clear">
            </div>
        </div>
    </form>
</div>