<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) )
die( '-1' );

function my_AJAX_CheckLatLong()
{
	$data = $_REQUEST;
	$str = "";
	$str .= CheckLatLong($data); /* Custom function "CheckLatLong($data)" called from Ajax function which in actual perform database operation.*/
	echo $str; 
	exit();
}

add_action('wp_ajax_CheckLatLong','my_AJAX_CheckLatLong');
add_action('wp_ajax_nopriv_CheckLatLong','my_AJAX_CheckLatLong');

function CheckLatLong($data)
{
	$address = urldecode($data['address']);
	$symbol = array(" ", ",", "_");
	$keyword = str_replace($symbol, "+", $address);

	$geocode 	= file_get_contents_curls('http://maps.google.com/maps/api/geocode/json?address=' . $keyword . '&sensor=false');
	$output 	= json_decode($geocode);
	
	if(isset($output->results[0]->geometry->location->lat) or isset($output->results[0]->geometry->location->lng))
	{
		$latitude = $post['latitude'] = $output->results[0]->geometry->location->lat;
		$longitude = $post['longitude'] = $output->results[0]->geometry->location->lng;
		$msg = $latitude.'::'.$longitude;
	}
	
	if(($output->status == 'ZERO_RESULTS') or (($latitude=='' || $longitude=='')))
	{
		$msg = 'Unable to find latitude and longitude. Please enter proper address.';
	}
	
	return $msg;
}

function file_get_contents_curls($url)
{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}

function current_location_page()
{
    $action = base64_decode($_REQUEST[ 'p_action' ]);
    if($action == "update_location")
	{
        $flag = 0;
		
		$id = $_POST['id'];
		$name = $_POST['name'];
		$address = trim($_POST['address']);
		$latitude = $_POST['latitude'];
		$longitude = $_POST['longitude'];
		
		if($name!='' && $address!='')
		{
			/*if($latitude=='' || $longitude=='')
			{
				$symbol = array(" ", ",", "_");
				$keyword = str_replace($symbol, "+", $address);
			
				$geocode 	= file_get_contents_curls('http://maps.google.com/maps/api/geocode/json?address=' . $keyword . '&sensor=false');
				$output 	= json_decode($geocode);
				
				if(isset($output->results[0]->geometry->location->lat) or isset($output->results[0]->geometry->location->lng))
				{
					$latitude = $post['latitude'] = $output->results[0]->geometry->location->lat;
					$longitude = $post['longitude'] = $output->results[0]->geometry->location->lng;
				}
				
				if(($output->status == 'ZERO_RESULTS') or (($latitude=='' || $longitude=='')))
				{
					$msg = 'LAT_LONG_NOT_DEFINED';
				}			
			}*/
			
				global $wpdb;
				$query = $wpdb->update( $wpdb->base_prefix . "current_location"  , array(
				'name'	=> $name,
				'address' => $address,
				'latitude' => $latitude,
				'longitude' => $longitude,
				'updated_date' => date("Y-m-d H:i:s")), array("id" => 1)
				);		
				$msg = "Location updated successfully.";
		}	
	}
    
    include(PLUGIN_CURRENT_LOCATION_DIR.'admin/current_location_update.php');
}