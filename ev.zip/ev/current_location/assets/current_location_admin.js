function validateLocation(me)
{
	flag = 1;
	
	jQuery( '.required' ).each(function(){
		if( jQuery.trim(jQuery( this ).val()) == ''  )
		{
			jQuery(this).css( 'border' , '1px solid red' );
			jQuery( this ).val('');
			flag = 0;
		}
		else
		{
			jQuery(this).css( 'border' , '1px solid lightgrey' );
		}		
	});
	
	jQuery('.numeric').each(function(){
		if (isNaN(jQuery.trim(jQuery( this ).val()))) {
			jQuery(this).css( 'border' , '1px solid red' );
			jQuery("#numeric_validation").html("Pleae enter only numbers");
			jQuery(this ).val('');
			flag = 0;
		}
		
	});
	
	if( flag == 1 )	
	{
		return true;
	}
	return false;
}