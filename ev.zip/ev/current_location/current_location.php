<?php
/*
Plugin Name: Current Location Plugin
Plugin URI: http://www.infocratsweb.com/
Description: Current Location Plugin is custom plugin to update the current location of rajeshmuniji.
Version: 1.0
Author: INFOCRATS Web Solutions
Author URI: http://www.infocratsweb.com/
*/

// don't load directly
if ( ! defined( 'ABSPATH' ) )
die( '-1' );

define('PLUGIN_CURRENT_LOCATION_DIR', plugin_dir_path(__FILE__));
define('PLUGIN_CURRENT_LOCATION_URL', plugin_dir_url(__FILE__));

require_once PLUGIN_CURRENT_LOCATION_DIR . 'admin/functions.php';
require_once PLUGIN_CURRENT_LOCATION_DIR . 'shortcodes.php';
//require_once PLUGIN_DIRECTORY_DIR . 'site/function.php';

// Display Current Location in Admin Menu
function current_location_wp_menu()
{
	add_menu_page('Current Location', 'Current Location', 'manage_options', 'current_location' , 'current_location_page', '' ,13);
}

// Hook To Add Current Location Menu Item To Wordpress Admin Section
add_action( 'admin_menu', 'current_location_wp_menu' );

// Check and Create table with name 'prefix_current_location' in database at the time of plugin installation
function current_location_install()
{
	global $wpdb;
	$table_name = $wpdb->prefix.'current_location';
	
	$charset_collate = $wpdb->get_charset_collate();
	
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(55) NOT NULL,
	`address` TEXT NOT NULL,
	`latitude` varchar(255) NOT NULL,
	`longitude` varchar(255) NOT NULL,
	`updated_date` datetime NOT NULL,
	PRIMARY KEY (`id`)
	) $charset_collate;";
	
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}

// Hook To Create table with name 'prefix_current_location' in database at the time of plugin installation
register_activation_hook( __FILE__, 'current_location_install' );

//Delete table with name 'prefix_contactus' in database at the time of plugin uninstallation
function current_location_uninstall()
{
	global $wpdb;
	$table = $wpdb->prefix."current_location";
	//$wpdb->query("DROP TABLE IF EXISTS $table");
}

// Hook To Delete table with name 'prefix_current_location' in database at the time of plugin uninstallation
register_deactivation_hook( __FILE__, 'current_location_uninstall' );


// Function To Add Plugin CSS And JS
function add_current_location_scripts()
{
	wp_register_script( 'current_location_admin_script' , PLUGIN_CURRENT_LOCATION_URL.'assets/current_location_admin.js' ); 
	wp_enqueue_script( 'current_location_admin_script');
}

// Hook To Add Plugin CSS And JS
add_action( 'admin_enqueue_scripts', 'add_current_location_scripts' );