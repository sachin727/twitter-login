<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) )
die( '-1' );

/*Function to trigger custom created shortcode*/
function DisplayCurrentLocation()
{	
		include_once PLUGIN_CURRENT_LOCATION_DIR . 'site/current_location.php';
}

/*Hook to create custom shortcode*/
add_shortcode( 'Current Location', 'DisplayCurrentLocation' );
?>