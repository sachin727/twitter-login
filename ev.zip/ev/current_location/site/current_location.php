<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) )
die( '-1' );
?>
<div class="col-lg-12">
</div>
<?php
global $wpdb;
$query = "SELECT * FROM ". $wpdb->base_prefix . "current_location WHERE id = 1";
$result =  $wpdb->get_row( $query );
?>
<div class="col-lg-12">
<table class="table" width="100%">
<tr><td>संपर्क व्यक्ति:</td><td><?php echo $result->name;?></td></tr>
<tr><td>वर्तमान स्थान:</td><td><?php echo $result->address;?></td></tr>
</table>
<div>&nbsp;</div>
<div id="map" style="width:100%;height:200px;"></div>
	
</div>

   <!-----------map-------------------->
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script>
<style>
      html, body, #map-canvas {
        height: 100%;
        margin: 0;
        padding: 0;
      }

    </style>


    <script>
	  
function initialize() {
  
  var x= <?php echo $result->latitude;?>;
  var y= <?php echo $result->longitude;?>;
  //var myLatlng = new google.maps.LatLng(-25.363882,131.044922);
  
  var myLatlng = new google.maps.LatLng(x,y);
  
  var mapOptions = {
    zoom: 16,
    center: myLatlng
  }
  var map = new google.maps.Map(document.getElementById('map'), mapOptions);

  var marker = new google.maps.Marker({
      position: myLatlng,
      map: map,
      title: '<?php echo $result->address;?>!'
  });
}

google.maps.event.addDomListener(window, 'load', initialize);

    </script>
    

 
<!-----------map-------------------->