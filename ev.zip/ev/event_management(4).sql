-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2017 at 08:01 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `event_management`
--
CREATE DATABASE IF NOT EXISTS `event_management` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `event_management`;

-- --------------------------------------------------------

--
-- Table structure for table `event_admin_login`
--

DROP TABLE IF EXISTS `event_admin_login`;
CREATE TABLE IF NOT EXISTS `event_admin_login` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password_login` varchar(100) DEFAULT NULL COMMENT 'admin@event',
  `status` tinyint(10) DEFAULT NULL COMMENT '0:inactive, 1:active',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `event_admin_login`
--

INSERT INTO `event_admin_login` (`id`, `username`, `email`, `password_login`, `status`, `create_time`, `update_time`, `timestamp`) VALUES
(1, 'admin', 'chetna@infocratsweb.com', '9d84703174f8f52fff3442e7a54ad2f2', 1, '2017-07-31 06:03:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `event_category`
--

DROP TABLE IF EXISTS `event_category`;
CREATE TABLE IF NOT EXISTS `event_category` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) DEFAULT NULL,
  `status` tinyint(10) DEFAULT NULL COMMENT '0:inactive,1:active',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `event_category`
--

INSERT INTO `event_category` (`id`, `category_name`, `status`, `create_time`, `update_time`, `timestamp`) VALUES
(1, 'Cultural', 1, '2017-07-31 05:47:20', NULL, '2017-07-31 00:17:20'),
(2, 'Food', 1, '2017-07-31 05:48:00', NULL, '2017-07-31 00:18:00'),
(3, 'Store', 1, '2017-07-31 05:48:00', NULL, '2017-07-31 00:18:00');

-- --------------------------------------------------------

--
-- Table structure for table `event_details`
--

DROP TABLE IF EXISTS `event_details`;
CREATE TABLE IF NOT EXISTS `event_details` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `event_category_id` varchar(50) DEFAULT NULL,
  `event_title` varchar(100) DEFAULT NULL,
  `event_image_orgpath` varchar(255) DEFAULT NULL,
  `event_image_systempath` varchar(255) DEFAULT NULL,
  `event_start_date` varchar(50) DEFAULT NULL,
  `event_end_date` varchar(50) DEFAULT NULL,
  `event_start_time` varchar(50) DEFAULT NULL,
  `event_end_time` varchar(50) DEFAULT NULL,
  `event_description` text,
  `event_venue` varchar(255) DEFAULT NULL,
  `event_venue_latitude` varchar(20) DEFAULT NULL,
  `event_venue_longitude` varchar(20) DEFAULT NULL,
  `status` tinyint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `event_details`
--

INSERT INTO `event_details` (`id`, `event_category_id`, `event_title`, `event_image_orgpath`, `event_image_systempath`, `event_start_date`, `event_end_date`, `event_start_time`, `event_end_time`, `event_description`, `event_venue`, `event_venue_latitude`, `event_venue_longitude`, `status`, `create_time`, `update_time`, `timestamp`) VALUES
(1, '1,2', '2ND edition of international show and convention', 'Mera-Banner.jpg', '2017_08_11_12_31_33_Mera-Banner.jpg', '2017-08-11', '2017-08-31', '09:30 AM', '02:00 PM', '2ND edition of international show and convention', 'janjeerwala sqaure indore', '22.7267501', '75.88107949999994', 1, '2017-08-11 12:31:33', NULL, '2017-08-11 07:01:33'),
(2, '2,3', 'Convergence India', 'events-heavenly-header.jpg', '2017_08_11_12_37_47_events-heavenly-header.jpg', '2017-08-11', '2017-08-31', '10:30 AM', '05:30 PM', 'Convergence India', 'abhay prashal indore', '22.7250472', '75.87767129999997', 1, '2017-08-11 12:37:47', NULL, '2017-08-11 07:07:47');

-- --------------------------------------------------------

--
-- Table structure for table `event_menu_images`
--

DROP TABLE IF EXISTS `event_menu_images`;
CREATE TABLE IF NOT EXISTS `event_menu_images` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `menu_event_id` bigint(255) DEFAULT NULL COMMENT 'AUTO ID of event_details',
  `menu_sub_event_id` bigint(255) DEFAULT NULL COMMENT 'AUTO ID of event_sub_event_details',
  `menu_image_orgpath` varchar(255) DEFAULT NULL,
  `menu_image_systempath` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `event_menu_images`
--

INSERT INTO `event_menu_images` (`id`, `menu_event_id`, `menu_sub_event_id`, `menu_image_orgpath`, `menu_image_systempath`, `create_time`, `update_time`, `timestamp`) VALUES
(1, 1, 2, 'menu_L_2.jpg', '2017_08_11_12_31_34_1_menu_menu_L_2.jpg', '2017-08-11 12:31:34', NULL, '2017-08-11 07:01:34'),
(2, 1, 2, 'menu_L_1.jpg', '2017_08_11_12_31_34_1_menu_menu_L_1.jpg', '2017-08-11 12:31:34', NULL, '2017-08-11 07:01:34'),
(3, 1, 3, 'menu_L_4.png', '2017_08_11_12_31_34_1_menu_menu_L_4.png', '2017-08-11 12:31:34', NULL, '2017-08-11 07:01:34'),
(4, 1, 3, 'menu_L_3.jpg', '2017_08_11_12_31_34_1_menu_menu_L_3.jpg', '2017-08-11 12:31:34', NULL, '2017-08-11 07:01:34'),
(5, 2, 4, 'menu_L_5.jpeg', '2017_08_11_12_37_48_2_menu_menu_L_5.jpeg', '2017-08-11 12:37:48', NULL, '2017-08-11 07:07:48');

-- --------------------------------------------------------

--
-- Table structure for table `event_stall_images`
--

DROP TABLE IF EXISTS `event_stall_images`;
CREATE TABLE IF NOT EXISTS `event_stall_images` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `stall_event_id` bigint(255) DEFAULT NULL COMMENT 'AUTO ID of event_details',
  `stall_sub_event_id` bigint(255) DEFAULT NULL COMMENT 'AUTO ID of event_sub_event_details',
  `stall_image_orgpath` varchar(255) DEFAULT NULL,
  `stall_image_systempath` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `event_stall_images`
--

INSERT INTO `event_stall_images` (`id`, `stall_event_id`, `stall_sub_event_id`, `stall_image_orgpath`, `stall_image_systempath`, `create_time`, `update_time`, `timestamp`) VALUES
(1, 1, 2, 'stall_L_2.jpg', '2017_08_11_12_31_33_1_stall_stall_L_2.jpg', '2017-08-11 12:31:34', NULL, '2017-08-11 07:01:34'),
(2, 1, 2, 'stall_L_1.jpg', '2017_08_11_12_31_34_1_stall_stall_L_1.jpg', '2017-08-11 12:31:34', NULL, '2017-08-11 07:01:34'),
(3, 1, 3, 'stall_L_5.jpg', '2017_08_11_12_31_34_1_stall_stall_L_5.jpg', '2017-08-11 12:31:34', NULL, '2017-08-11 07:01:34'),
(4, 1, 3, 'stall_L_4.jpg', '2017_08_11_12_31_34_1_stall_stall_L_4.jpg', '2017-08-11 12:31:34', NULL, '2017-08-11 07:01:34'),
(5, 1, 3, 'stall_L_3.jpg', '2017_08_11_12_31_34_1_stall_stall_L_3.jpg', '2017-08-11 12:31:34', NULL, '2017-08-11 07:01:34'),
(6, 2, 4, 'stall_L_8.png', '2017_08_11_12_37_48_2_stall_stall_L_8.png', '2017-08-11 12:37:48', NULL, '2017-08-11 07:07:48'),
(7, 2, 4, 'stall_L_7.jpg', '2017_08_11_12_37_48_2_stall_stall_L_7.jpg', '2017-08-11 12:37:48', NULL, '2017-08-11 07:07:48'),
(8, 2, 4, 'stall_L_6.jpg', '2017_08_11_12_37_48_2_stall_stall_L_6.jpg', '2017-08-11 12:37:48', NULL, '2017-08-11 07:07:48');

-- --------------------------------------------------------

--
-- Table structure for table `event_store_images`
--

DROP TABLE IF EXISTS `event_store_images`;
CREATE TABLE IF NOT EXISTS `event_store_images` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `store_event_id` bigint(255) DEFAULT NULL COMMENT 'AUTO ID of event_details',
  `store_sub_event_id` bigint(255) DEFAULT NULL COMMENT 'AUTO ID of event_sub_event_details',
  `store_image_orgpath` varchar(255) DEFAULT NULL,
  `store_image_systempath` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `event_store_images`
--

INSERT INTO `event_store_images` (`id`, `store_event_id`, `store_sub_event_id`, `store_image_orgpath`, `store_image_systempath`, `create_time`, `update_time`, `timestamp`) VALUES
(1, 2, 4, 'store-images-3.jpg', '2017_08_11_12_37_48_2_store_store-images-3.jpg', '2017-08-11 12:37:48', NULL, '2017-08-11 07:07:48'),
(2, 2, 4, 'store2.jpg', '2017_08_11_12_37_48_2_store_store2.jpg', '2017-08-11 12:37:48', NULL, '2017-08-11 07:07:48'),
(3, 2, 4, 'events.png', '2017_08_11_12_37_48_2_store_events.png', '2017-08-11 12:37:48', NULL, '2017-08-11 07:07:48'),
(4, 2, 5, 'images.jpg', '2017_08_11_12_37_48_2_store_images.jpg', '2017-08-11 12:37:48', NULL, '2017-08-11 07:07:48'),
(5, 2, 5, 'events-heavenly-header.jpg', '2017_08_11_12_37_48_2_store_events-heavenly-header.jpg', '2017-08-11 12:37:48', NULL, '2017-08-11 07:07:48'),
(6, 2, 5, 'events.png', '2017_08_11_12_37_48_2_store_events.png', '2017-08-11 12:37:48', NULL, '2017-08-11 07:07:48'),
(7, 2, 5, 'concert-img.jpg', '2017_08_11_12_37_48_2_store_concert-img.jpg', '2017-08-11 12:37:48', NULL, '2017-08-11 07:07:48');

-- --------------------------------------------------------

--
-- Table structure for table `event_sub_event_details`
--

DROP TABLE IF EXISTS `event_sub_event_details`;
CREATE TABLE IF NOT EXISTS `event_sub_event_details` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(255) DEFAULT NULL COMMENT 'AUTO ID of event_details',
  `sub_event_cat_id` varchar(50) DEFAULT NULL COMMENT 'AUTO ID of event_category',
  `sub_event_icon_orgpath` varchar(255) DEFAULT NULL,
  `sub_event_icon_systempath` varchar(255) DEFAULT NULL,
  `sub_event_title` varchar(255) DEFAULT NULL,
  `sub_event_description` text,
  `sub_event_background` text,
  `sub_event_artist_name` varchar(255) DEFAULT NULL,
  `sub_event_cordinators` varchar(255) DEFAULT NULL,
  `sub_event_participants` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `event_sub_event_details`
--

INSERT INTO `event_sub_event_details` (`id`, `event_id`, `sub_event_cat_id`, `sub_event_icon_orgpath`, `sub_event_icon_systempath`, `sub_event_title`, `sub_event_description`, `sub_event_background`, `sub_event_artist_name`, `sub_event_cordinators`, `sub_event_participants`, `create_time`, `update_time`, `timestamp`) VALUES
(1, 1, '1', 'mera-event.png', '2017_08_11_12_31_33_1_mera-event.png', 'Startup India', 'Startup India Description', 'Startup India Background', 'Artist Name1, Artist Name2', 'Cordinator1, Cordinator2,Cordinator3', 'Participant1,Participant2,Participant3,Participant4', '2017-08-11 12:31:33', NULL, '2017-08-11 07:01:33'),
(2, 1, '2', 'images.jpg', '2017_08_11_12_31_33_1_images.jpg', 'Chinese Speical', 'Chinese Speical Description', 'Chinese Speical Background', NULL, NULL, NULL, '2017-08-11 12:31:33', NULL, '2017-08-11 07:01:33'),
(3, 1, '2', 'store-images-3.jpg', '2017_08_11_12_31_33_1_store-images-3.jpg', 'Street Food Festival', 'Street Food Festival Description', 'Street Food Festival Background', NULL, NULL, NULL, '2017-08-11 12:31:33', NULL, '2017-08-11 07:01:33'),
(4, 2, '2', 'images.jpg', '2017_08_11_12_37_47_2_images.jpg', 'Rajasthani Dhaba', 'Rajasthani Dhaba Description', 'Rajasthani Dhaba Background', NULL, NULL, NULL, '2017-08-11 12:37:47', NULL, '2017-08-11 07:07:47'),
(5, 2, '3', 'store-images-3.jpg', '2017_08_11_12_37_47_2_store-images-3.jpg', 'Space Show', 'Space Show Description', 'Space Show Background', NULL, NULL, NULL, '2017-08-11 12:37:47', NULL, '2017-08-11 07:07:47'),
(6, 2, '3', 'store2.jpg', '2017_08_11_12_37_47_2_store2.jpg', 'Startup India', 'Startup India Description', 'Startup India Background', NULL, NULL, NULL, '2017-08-11 12:37:47', NULL, '2017-08-11 07:07:47');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
