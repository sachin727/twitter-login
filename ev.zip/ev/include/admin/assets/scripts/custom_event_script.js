/* Check location on Map js*/
function CheckLatLong(me, base_url)
	{
		//jQuery(me).addClass('ajax-loader');
		jQuery(me).attr('disabled','disabled');
		jQuery('#chk_msg_id').html("Pease wait. Searching address...!");
		var address = encodeURIComponent(jQuery("#address_sys").val().trim());
		
		var data	= '?address='+address;

		request_Url =  base_url+'admin/events/check_lat_long'+ data;
		jQuery.ajax({  
		type: 'POST',
		url:  request_Url,
		success: function(data, textStatus, XMLHttpRequest){  
		data = data.split( '::' );
		if(jQuery.trim(data) == 'Unable to find latitude and longitude. Please enter proper address.' )
		{
			alert(data);
			jQuery('#latitude').val("");
			jQuery('#longitude').val("");
		}
		else
		{
			jQuery('#latitude').val("");
			jQuery('#longitude').val("");
			initialize2(data[0], data[1]);
		}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown){  
		}
		});
		//jQuery(me).removeClass('ajax-loader');
		jQuery(me).removeAttr('disabled');
		jQuery('#chk_msg_id').html("");
		return false;
	}

	function initialize2(lat2, long2)
	{
		var latLng = new google.maps.LatLng(lat2, long2);
		  var map = new google.maps.Map(document.getElementById('mapCanvas'), {
			zoom: 18,
			center: latLng,
			mapTypeId: google.maps.MapTypeId.ROADMAP
		  });
		  var marker = new google.maps.Marker({
			position: latLng,
			title: 'Point A',
			map: map,
			draggable: true
		  });

		  // Update current position info.
		  updateMarkerPosition(latLng);
		  geocodePosition(latLng);

		  // Add dragging event listeners.
		  google.maps.event.addListener(marker, 'dragstart', function() {
			updateMarkerAddress('Dragging...');
		  });

		  google.maps.event.addListener(marker, 'drag', function() {
			updateMarkerStatus('Dragging...');
			updateMarkerPosition(marker.getPosition());
		  });

		  google.maps.event.addListener(marker, 'dragend', function() {
			updateMarkerStatus('Drag ended');
			geocodePosition(marker.getPosition());
		  });
	}
	var geocoder = new google.maps.Geocoder();

	function geocodePosition(pos) {
	  geocoder.geocode({
		latLng: pos
	  }, function(responses) {
		if (responses && responses.length > 0) {
		  updateMarkerAddress(responses[0].formatted_address);
		} else {
		  updateMarkerAddress('Cannot determine address at this location.');
		}
	  });
	}

	function updateMarkerStatus(str) {
	  document.getElementById('markerStatus').innerHTML = str;
	}

	function updateMarkerPosition(latLng) {
		jQuery('#latitude').val(latLng.lat());
		jQuery('#longitude').val(latLng.lng());
	}

	function updateMarkerAddress(str) {
	  document.getElementById('address').innerHTML = str;
	}

	function initialize() {
	  var latLng = new google.maps.LatLng(29.457572631189898,-98.49853515625);
	  //var latLng = new google.maps.LatLng('','');
	  var map = new google.maps.Map(document.getElementById('mapCanvas'), {
		zoom: 18,
		center: latLng,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	  });
	  var marker = new google.maps.Marker({
		position: latLng,
		title: 'Point A',
		map: map,
		draggable: true
	  });

	  // Update current position info.
	  //updateMarkerPosition(latLng);
	  geocodePosition(latLng);

	  // Add dragging event listeners.
	  google.maps.event.addListener(marker, 'dragstart', function() {
		updateMarkerAddress('Dragging...');
	  });

	  google.maps.event.addListener(marker, 'drag', function() {
		updateMarkerStatus('Dragging...');
		updateMarkerPosition(marker.getPosition());
	  });

	  google.maps.event.addListener(marker, 'dragend', function() {
		updateMarkerStatus('Drag ended');
		geocodePosition(marker.getPosition());
	  });
	}

	// Onload handler to fire off the app.
	google.maps.event.addDomListener(window, 'load', initialize);
/* Check location on Map js*/
	
	
/* Datepickers js*/
jQuery(document).ready(function(){
		
	jQuery('#event_start_time').timepicker({ 'scrollDefault': 'now' });
	jQuery('#event_end_time').timepicker({ 'scrollDefault': 'now' });
	
});
/* Datepickers js*/

/* Accordian js */
jQuery(document).on('show','.accordion', function (e) {
	 //$('.accordion-heading i').toggleClass(' ');
	 jQuery(e.target).prev('.accordion-heading').addClass('accordion-opened');
});

jQuery(document).on('hide','.accordion', function (e) {
	jQuery(this).find('.accordion-heading').not($(e.target)).removeClass('accordion-opened');
	//$('.accordion-heading i').toggleClass('fa-chevron-right fa-chevron-down');
});
/* Accordian js */

jQuery(document).ready(function(){
		
	var event_category = jQuery('[name^="event_category[]"]:checked').length;
	if(event_category == 0)
	{
		jQuery("#accordion2 .accordion-heading").accordion({ disabled: true });
	}
	else
	{
		jQuery("#accordion2 .accordion-heading").accordion("enable");
	}
	
});	

function CheckCategory(cat_id)
{
	var checkbox_val = jQuery('[id="event_category_'+cat_id+'"]').val();
	 if(jQuery('[id="event_category_'+cat_id+'"]').is(":checked")){
				jQuery('#accordion2 #div_accordian_'+cat_id+'').accordion("enable");
				
				//disable div on-check category
				jQuery('#accordion2 #collapse_'+cat_id+'').accordion("enable");
				
            }
            else if(jQuery('[id="event_category_'+cat_id+'"]').is(":not(:checked)")){
				jQuery('#accordion2 #div_accordian_'+cat_id+'').accordion({ disabled: true });
				
				//disable divon-uncheck category
				jQuery('#accordion2 #collapse_'+cat_id+'').accordion({ disabled: true });
				
            }
}

function AddCategoryRow(me,cat_id)
{
	var count = jQuery('input[id^=sub_event_row_hidden_'+cat_id+']').size();
	//alert(cat_id+':::'+count);
	var answers = jQuery('#no_of_sub_events_'+cat_id).val();
	
	if(cat_id == 1)
	{
		jQuery('#sub_events_section_'+cat_id).append('<div id="sub_event_row_'+count+'" class="sub_event_row"><input type="hidden" name="sub_event_row_hidden[]" id="sub_event_row_hidden_'+cat_id+'" value="'+count+'"/><div class="row"><div class="col-sm-3"><div class="form-group">Sub-Event Icon <input type="file" name="sub_event_icon[]" id="sub_event_icon_'+count+'" onchange="return ValidateSubEventIcon(this,'+cat_id+','+count+');" class="required_add_subevent" placeholder="Sub-Event Icon" title="Sub-Event Icon"/></div><div id="sub_event_icon_error_'+count+'"></div></div><div class="col-sm-3"><div class="form-group"><input type="text" name="sub_event_title[]" class="form-control required_add_subevent" placeholder="Sub-Event Title" title="Sub-Event Title"/></div></div><div class="col-sm-3"><div class="form-group"><textarea name="sub_event_description[]" class="form-control required_add_subevent" placeholder="Sub-Event Description" title="Sub-Event Description"></textarea></div></div><div class="col-sm-3"><div class="form-group"><textarea name="sub_event_background[]" class="form-control required_add_subevent"  placeholder="Sub-Event Background" title="Sub-Event Background"></textarea></div></div><div class="col-sm-3">&nbsp;</div><div class="clearfix"></div><div class="col-sm-3"><div class="form-group"><input type="text" name="sub_event_artist_name[]" class="form-control required_add_subevent" placeholder="Sub-Event Artist Name" title="Sub-Event Artist Name"/></div></div><div class="col-sm-3"><div class="form-group"><input type="text" name="sub_event_cordinators[]" class="form-control required_add_subevent" placeholder="Sub-Event Cordinators" title="Sub-Event Cordinators. Enter comma separated names here."/></div></div><div class="col-sm-3"><div class="form-group"><input type="text" name="sub_event_participants[]" class="form-control required_add_subevent" placeholder="Sub-Event Participants" title="Sub-Event Participants. Enter comma separated names here."/></div></div><br/><div class="col-sm-1"><a href="#" id="sub_event_delete_'+count+'" class="btn btn-default" onclick="return DeleteCategoryRow('+count+','+cat_id+')">Delete</a></div></div></div><hr>');
	}
	
	if(cat_id == 2)
	{
		jQuery('#sub_events_section_'+cat_id).append('<div id="sub_event_row_'+count+'" class="sub_event_row"><input type="hidden" name="sub_event_row_hidden[]" id="sub_event_row_hidden_'+cat_id+'" value="'+count+'"/><div class="row"><div class="col-sm-3"><div class="form-group">Sub-Event Icon <input type="file" name="sub_event_icon[]" id="sub_event_icon_'+count+'" onchange="return ValidateSubEventIcon(this,'+cat_id+','+count+');" class="required_add_subevent" placeholder="Sub-Event Icon" title="Sub-Event Icon"/><div id="sub_event_icon_error_'+count+'"></div></div></div><div class="col-sm-3"><div class="form-group"><input type="text" name="sub_event_title[]" class="form-control required_add_subevent" placeholder="Sub-Event Title" title="Sub-Event Title"/></div></div><div class="col-sm-3"><div class="form-group"><textarea name="sub_event_description[]" class="form-control required_add_subevent" placeholder="Sub-Event Description" title="Sub-Event Description"></textarea></div></div><div class="col-sm-3"><div class="form-group"><textarea name="sub_event_background[]" class="form-control required_add_subevent"  placeholder="Sub-Event Background" title="Sub-Event Background"></textarea></div></div><div class="col-sm-3"><div class="form-group">Stall Layout <input type="file" name="stall_layout[]" class="required_add_subevent" title="Stall Layout" /></div></div><div class="col-sm-3"><div class="form-group">Menu Layout <input type="file" name="menu_layout[]" class="required_add_subevent" title="Menu Layout" /></div></div><br/><br/><br/><div class="col-sm-1"><a href="#" id="sub_event_delete_'+count+'" class="btn btn-default" onclick="return DeleteCategoryRow('+count+','+cat_id+')">Delete</a></div></div></div><hr>');
	}
	
	if(cat_id == 3)
	{
		jQuery('#sub_events_section_'+cat_id).append('<div id="sub_event_row_'+count+'" class="sub_event_row"><input type="hidden" name="sub_event_row_hidden[]" id="sub_event_row_hidden_'+cat_id+'" value="'+count+'"/><div class="row"><div class="col-sm-3"><div class="form-group">Sub-Event Icon <input type="file" name="sub_event_icon[]" id="sub_event_icon_'+count+'" onchange="return ValidateSubEventIcon(this,'+cat_id+','+count+');" class="required_add_subevent" placeholder="Sub-Event Icon" title="Sub-Event Icon"/><div id="sub_event_icon_error_'+count+'"></div></div></div><div class="col-sm-3"><div class="form-group"><input type="text" name="sub_event_title[]" class="form-control required_add_subevent" placeholder="Sub-Event Title" title="Sub-Event Title"/></div></div><div class="col-sm-3"><div class="form-group"><textarea name="sub_event_description[]" class="form-control required_add_subevent" placeholder="Sub-Event Description" title="Sub-Event Description"></textarea></div></div><div class="col-sm-3"><div class="form-group"><textarea name="sub_event_background[]" class="form-control required_add_subevent"  placeholder="Sub-Event Background" title="Sub-Event Background"></textarea></div></div><div class="col-sm-3"><div class="form-group">Store images <input type="file" name="store_images[]" class="required_add_subevent" title="Multiple Store images" /></div></div><br/><br/><div class="col-sm-1"><a href="#" id="sub_event_delete_'+count+'" class="btn btn-default" onclick="return DeleteCategoryRow('+count+','+cat_id+')">Delete</a></div></div></div><hr>');
	}
	
	
	var count = jQuery('input[id^=sub_event_row_hidden_'+cat_id+']').size();
	
	jQuery('#no_of_sub_events_'+cat_id).html(count);
	jQuery('#no_of_sub_events_hidden_'+cat_id).val(count);
	if (count>9) {
	  jQuery('#add_sub_events_btn_'+cat_id).prop("disabled", true);
	}
	if (count<9) {
	  jQuery('#add_sub_events_btn_'+cat_id).prop("disabled", false);
	}				  
}


function DeleteCategoryRow(row_no,cat_id)
{

	jQuery('#sub_events_section_'+cat_id).find('#sub_event_row_'+row_no).remove();
	
	//jQuery('#sub_event_row_'+row_no).remove();
	// var count = jQuery('.sub_event_row').size();
	
	var count = jQuery('input[id^=sub_event_row_hidden_'+cat_id+']').size();
	jQuery('#no_of_sub_events_'+cat_id).html(count);
	jQuery('#no_of_sub_events_hidden_'+cat_id).val(count);
	if (count>9) {
	  jQuery('#add_sub_events_btn_'+cat_id).prop("disabled", true);
	}
	if (count<9) {
	  jQuery('#add_sub_events_btn_'+cat_id).prop("disabled", false);
	}	
}