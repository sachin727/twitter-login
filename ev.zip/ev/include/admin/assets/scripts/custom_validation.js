/* Admin login */
function validate_admin_login()
{
	flag=1;
	jQuery(".required_login").each(function(){
	
		if(jQuery.trim(jQuery(this).val()) == '')
		{
			jQuery(this).addClass("required_alert");
			flag = 0;
		}
		else
		{
			jQuery(this).removeClass("required_alert");
		}
	});
	
	if(flag == 0){
		return false;
	}
}

/* Event Image Upload */
var _valideventFile = [".jpg", ".JPG", ".jpeg", ".JPEG", ".png", ".PNG", "gif", "GIF"];
function UploadEventImage(event_file)
{
	jQuery('#event_image_error').html("");
	if (event_file.type == "file") {
        var sFileName = event_file.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _valideventFile.length; j++) {
                var sCurExtension = _valideventFile[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
			
			var event_image = jQuery('#event_image').val().trim();
			if(event_image=='')
			{
				jQuery('#event_image').addClass("required_alert");
				jQuery('#event_image_error').html('Please upload event image');
				return false;
			}
			
			 var filesize = event_file.files[0].size;
             filesize = filesize / 1048576; //size in mb 
			 if(filesize > 2)
			 {
				jQuery('#event_image_error').html("Maximum 2MB file size is allowed");
				event_file.value = "";
				return false;
			 }
			 
            if (!blnValid) {
                jQuery('#event_image_error').append("" + sFileName + " is invalid, allowed extensions are: " + _valideventFile.join(", "));
                event_file.value = "";
                return false;
            }
        }
    }
    return true;
}


//Sub-Event Icon File START 
function ValidateSubEventIcon(me,cat_id,count) {

	for(var k=1; k <= 3; k++)
	{
	
		var sub_event_icon_file = document.getElementById('sub_event_icon_'+count);

		for (var i = 0; i < sub_event_icon_file.files.length; i++) {
		   var e = sub_event_icon_file.files[i];
		   var eName=e.name;
			var eventfilesize=e.size;
			eventfilesize = eventfilesize / 1048576;
			var eventfilecount=sub_event_icon_file.files.length;
			if (!(e.type=='image/jpg' || e.type=='image/jpeg' || e.type=='image/png' || e.type=='image/gif'))
			{
			alert(e.type + " is not a valid file!");
			jQuery('div #sub_events_section_'+k+' #sub_event_icon_error_'+count).html('Invalid file type');
			jQuery('div #sub_events_section_'+k+' #sub_event_icon_error_'+count).addClass("required_text");
			flag=0;
			return false;
			}
			
			else if(eventfilesize > 2)
			{
			alert(eName + " file size should not exceed more than 2MB" );
			jQuery('div #sub_events_section_'+k+' #sub_event_icon_error_'+count).html('File size should not exceed more than 2MB');
			jQuery('div #sub_events_section_'+k+' #sub_event_icon_error_'+count).addClass("required_text");
			flag=0;
			return false;
			}
			else{
			//jQuery("#sub_event_icon_error_"+count).html(eventfilecount + " File uploaded");
			jQuery('div #sub_events_section_'+k+' #sub_event_icon_error_'+count).html('');
			jQuery('div #sub_events_section_'+k+' #sub_event_icon_error_'+count).removeClass("required_text");
			jQuery('div #sub_events_section_'+k+' #sub_event_icon_error_'+count).removeClass("required_alert");
			}
		}
	}
	if(flag == 0)
	{
		return false;
	}
}
//Sub-Event Icon File END


function validate_add_event()
{
	var flag_subevent_icon_msg = jQuery('div[id^="sub_event_icon_error_"]').html();
	
    var flag_img_msg = jQuery('#event_image_error').html();
    if (flag_img_msg != '' || flag_subevent_icon_msg!='') {
	return false;
    }

	flag = 1;
	jQuery( '.required_add_event' ).each(function(){
		if( jQuery.trim(jQuery( this ).val()) == ''  )
		{
			jQuery(this).addClass("required_alert");
			flag = 0;
		}
		else
		{
			jQuery(this).removeClass("required_alert");
		}		
	});
	
	//validate  for special characters
	jQuery( ".noeventspecharallowed" ).each(function(){
	var val = jQuery.trim(jQuery( this ).val());
	if (val != '') {
		var exp = /[`~!@#$%^&*()_|+\=?;:'",<>\{\}\[\]\\\/]/gi;
		if(!exp.test(val) == false)
		{
            jQuery(this).addClass("required_alert");
		    flag = 0;
		}
		else
		{
		    jQuery(this).removeClass("required_alert");
		}
	}
	});
	
	
	var event_image = jQuery('#event_image').val().trim();
	if(event_image=='')
	{
		jQuery('#event_image_error').html('Please upload event image');
		flag=0
	}
	else
	{
		jQuery('#event_image_error').html('');
	}
	
    /*latlong required */
	jQuery('.latlong_required' ).each(function(){
		if( jQuery.trim(jQuery( this ).val()) == '' )
		{
			jQuery("#event_venue_error").html("Please click on Check On Map button to check for proper address");
			flag = 0;
		}
		else
		{
            jQuery("#event_venue_error").html(""); 
		}		
	});
	/*End latlong required*/
	
	
	/* category validations */
	var event_category = jQuery('input[name^="event_category[]"]:checked').length;
	
	for(var k=1; k <= event_category; k++)
	{
		jQuery( 'div #sub_events_section_'+k+' .required_add_subevent' ).each(function(){
			if( jQuery.trim(jQuery( this ).val()) == ''  )
			{
				jQuery(this).addClass("required_alert");
				flag = 0;
			}
			else
			{
				jQuery(this).removeClass("required_alert");
			}		
		});
	}
	
	alert(flag);
	
	if (flag == 0) {
	    return false;
	}
}
